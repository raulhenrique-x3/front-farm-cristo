export interface IUser {
  id: string;
  first_name: string;
  email: string;
}
